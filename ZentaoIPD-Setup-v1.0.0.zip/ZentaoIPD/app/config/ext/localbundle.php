<?php
$config->requestType = 'GET';
$config->checkVersion = false;
$config->timezone = 'Asia/Shanghai';
$config->default->lang = 'zh-cn';
