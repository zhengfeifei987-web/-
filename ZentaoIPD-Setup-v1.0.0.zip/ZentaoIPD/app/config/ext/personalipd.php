<?php
/** Register attachment ownership; never leave custom object types unrestricted. */
$config->objectTables['ipddeliverable'] = '`' . $config->db->prefix . 'ipddeliverable`';
$config->objectTables['ipdmeeting'] = '`' . $config->db->prefix . 'ipdmeeting`';
