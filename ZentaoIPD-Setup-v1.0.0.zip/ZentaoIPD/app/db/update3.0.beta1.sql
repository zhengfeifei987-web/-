UPDATE `zt_story` SET `source` = 'customer' WHERE `source` = 'custom';
ALTER TABLE `zt_action` CHANGE `product` `product` VARCHAR( 255 ) NOT NULL;
ALTER TABLE `zt_history` CHANGE `diff` `diff` MEDIUMTEXT NOT NULL;
ALTER TABLE `zt_project` ADD `order` SMALLINT UNSIGNED NOT NULL AFTER `whitelist`;
